# Bot Options Binary — Experiment on Quotex (educational only)
# Uses an unofficial library to communicate with the platform (warning: experimental only)
from pyquotex import Quotex
import time, math

# ----- Settings -----
EMAIL = "your_email@example.com"
PASSWORD = "your_password"
SYMBOL = "EURUSD"           # financial asset
TIMEFRAME = 60              # trade duration in minutes
RISK_PERCENT = 1.0          # risk percentage per trade %
MAX_TRADES = 2              # maximum number of open trades at the same time
PAYOUT = 0.8                # estimated payout

RSI_PERIOD = 14
SMA_PERIOD = 50

# ----- Platform connection -----
client = Quotex(email=EMAIL, password=PASSWORD)
connected, msg = client.connect()

if not connected:
    print("❌ Connection failed:", msg)
    exit()

# ----- Wait for next candle -----
def wait_next_candle(timeframe):
    now = int(time.time())
    wait = timeframe * 60 - (now % (timeframe * 60))
    time.sleep(wait + 1)

# ----- Analysis functions -----
def calc_rsi(closes, period=RSI_PERIOD):
    gains = []
    losses = []

    for i in range(1, len(closes)):
        diff = closes[i] - closes[i-1]
        gains.append(max(diff, 0))
        losses.append(max(-diff, 0))

    avg_gain = sum(gains[:period]) / period
    avg_loss = sum(losses[:period]) / period

    for i in range(period, len(gains)):
        avg_gain = (avg_gain * (period - 1) + gains[i]) / period
        avg_loss = (avg_loss * (period - 1) + losses[i]) / period

    if avg_loss == 0:
        return 100

    rs = avg_gain / avg_loss
    return 100 - (100 / (1 + rs))

def calc_sma(closes, period=SMA_PERIOD):
    if len(closes) < period:
        return sum(closes) / len(closes)
    return sum(closes[-period:]) / period

# ----- Risk management -----
def calc_amount(balance, risk_percent, payout=PAYOUT):
    risk = balance * (risk_percent / 100)
    amount = risk / payout
    return max(amount, 1.0)

# ----- Trade execution -----
def open_trade(direction, amount):
    result = client.buy_simple(SYMBOL, amount, direction, TIMEFRAME)
    print(f"✅ Trade opened {direction} with amount {amount}")
    return result

def count_trades_open():
    trades = client.get_open_trades()
    return len([t for t in trades if t["symbol"] == SYMBOL])

# ----- Main loop -----
print("🚀 Bot started...")

while True:

    wait_next_candle(TIMEFRAME)

    if count_trades_open() >= MAX_TRADES:
        print("⚠️ Max open trades reached")
        continue

    candles = client.get_candles(symbol=SYMBOL, timeframe=TIMEFRAME, limit=200)
    closes = [c["close"] for c in candles]

    rsi = calc_rsi(closes)
    rsi_prev = calc_rsi(closes[:-1])

    sma = calc_sma(closes)

    last = candles[-1]

    direction = None

    # RSI crossover logic
    if rsi_prev < 30 and rsi > 30 and last["close"] > sma:
        direction = "call"

    elif rsi_prev > 70 and rsi < 70 and last["close"] < sma:
        direction = "put"

    if direction:

        balance = client.get_balance()

        amount = calc_amount(balance, RISK_PERCENT)

        open_trade(direction, amount)

    else:
        print("No signal...")
