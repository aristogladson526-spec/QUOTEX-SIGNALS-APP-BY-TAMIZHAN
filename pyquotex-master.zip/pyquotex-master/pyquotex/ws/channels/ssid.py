import orjson

from pyquotex.ws.channels.base import Base


class Ssid(Base):
    """Class for Quotex API ssid websocket channel."""

    name = "ssid"

    async def __call__(self, ssid: str) -> None:
        """Method to send message to ssid websocket channel.

        :param ssid: The session identifier.
        """
        payload = {
            "session": ssid,
            "isDemo": self.api.account_type,
            "tournamentId": 0
        }
        data = f'42["authorization",{orjson.dumps(payload).decode()}]'
        await self.send_websocket_request(data)
